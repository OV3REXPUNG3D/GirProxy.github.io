import { Gamepad2, Search, Play } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { GameEntry } from "@/lib/games-data";
import { Swords, Puzzle, Car, Crosshair } from "lucide-react";

const categoryIcon: Record<string, React.ReactNode> = {
  Action: <Swords className="h-3.5 w-3.5" />,
  Arcade: <Gamepad2 className="h-3.5 w-3.5" />,
  Puzzle: <Puzzle className="h-3.5 w-3.5" />,
  Racing: <Car className="h-3.5 w-3.5" />,
  Shooter: <Crosshair className="h-3.5 w-3.5" />,
};

interface Props {
  games: GameEntry[];
  categories: string[];
  activeCategory: string;
  search: string;
  onCategoryChange: (c: string) => void;
  onSearchChange: (s: string) => void;
  onPlay: (url: string) => void;
}

export default function GamesView({
  games,
  categories,
  activeCategory,
  search,
  onCategoryChange,
  onSearchChange,
  onPlay,
}: Props) {
  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="flex items-center gap-3 px-4 py-3 border-b border-border bg-card/30">
        <Gamepad2 className="h-5 w-5 text-purple-400" />
        <h2 className="font-semibold text-sm">Game Stash</h2>
        <Badge variant="secondary" className="text-[10px]">{games.length} games</Badge>
        <div className="flex-1" />
        <div className="relative w-48">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search games..."
            className="pl-7 h-8 text-xs"
          />
        </div>
      </div>

      <div className="flex items-center gap-1 px-4 py-2 border-b border-border overflow-x-auto">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => onCategoryChange(cat)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-colors shrink-0 ${
              activeCategory === cat
                ? "bg-purple-500/15 text-purple-300 border border-purple-500/30"
                : "text-muted-foreground hover:bg-muted border border-transparent"
            }`}
          >
            {cat !== "All" && categoryIcon[cat]}
            {cat}
          </button>
        ))}
      </div>

      <ScrollArea className="flex-1">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 p-4">
          {games.map((game) => (
            <button
              key={game.id}
              onClick={() => onPlay(game.url)}
              className="group flex flex-col items-center text-center gap-2 p-4 rounded-xl bg-card/50 border border-border/50 hover:border-purple-500/30 hover:bg-purple-500/5 transition-all hover:-translate-y-0.5"
            >
              <div className="text-3xl">{game.emoji}</div>
              <div className="space-y-0.5">
                <p className="text-sm font-medium group-hover:text-purple-300 transition-colors">{game.title}</p>
                <p className="text-[11px] text-muted-foreground line-clamp-2">{game.description}</p>
              </div>
              <Badge variant="outline" className="text-[10px] mt-1 flex items-center gap-1">
                {categoryIcon[game.category]}
                {game.category}
              </Badge>
              <div className="flex items-center gap-1 text-[10px] text-purple-400 opacity-0 group-hover:opacity-100 transition-opacity">
                <Play className="h-3 w-3" />
                Click to Play
              </div>
            </button>
          ))}
        </div>

        {games.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <Gamepad2 className="h-10 w-10 mb-3 opacity-30" />
            <p className="text-sm">No games found</p>
            <p className="text-xs">Try a different search or category</p>
          </div>
        )}
      </ScrollArea>
    </div>
  );
}
