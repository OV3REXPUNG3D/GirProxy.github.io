import { useState } from "react";
import { Star, Search, Trash2, Globe, ExternalLink } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { getFaviconUrl } from "@/lib/proxy";

interface Bookmark {
  id: string;
  url: string;
  title: string;
}

interface Props {
  bookmarks: Bookmark[];
  history: string[];
  onNavigate: (url: string) => void;
  onDeleteBookmark: (id: string) => void;
}

export default function BookmarkSidebar({ bookmarks, history, onNavigate, onDeleteBookmark }: Props) {
  const [search, setSearch] = useState("");
  const filtered = bookmarks.filter(
    (b) =>
      b.title.toLowerCase().includes(search.toLowerCase()) ||
      b.url.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full">
      <div className="p-3 border-b border-border">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1.5">
          <Star className="h-3.5 w-3.5" />
          Bookmarks
        </h2>
        <div className="relative">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search bookmarks..."
            className="pl-7 h-8 text-xs"
          />
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-2 space-y-0.5">
          {filtered.map((bm) => (
            <div
              key={bm.id}
              className="group flex items-center gap-2 px-2.5 py-2 rounded-md hover:bg-purple-500/10 cursor-pointer transition-colors"
              onClick={() => onNavigate(bm.url)}
            >
              <img
                src={getFaviconUrl(bm.url)}
                alt=""
                className="h-4 w-4 rounded-sm shrink-0"
                onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
              />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium truncate">{bm.title}</p>
                <p className="text-[10px] text-muted-foreground truncate">{new URL(bm.url).hostname}</p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                onClick={(e) => { e.stopPropagation(); onDeleteBookmark(bm.id); }}
              >
                <Trash2 className="h-3 w-3 text-muted-foreground hover:text-destructive" />
              </Button>
            </div>
          ))}
          {filtered.length === 0 && (
            <div className="text-center py-6 text-xs text-muted-foreground">No bookmarks found</div>
          )}
        </div>

        {history.length > 0 && (
          <>
            <div className="px-3 py-2 border-t border-border mt-2">
              <h3 className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                <ExternalLink className="h-3 w-3" />
                Recent
              </h3>
            </div>
            <div className="p-2 space-y-0.5">
              {history.slice(0, 10).map((url, i) => (
                <div
                  key={i}
                  className="flex items-center gap-2 px-2.5 py-2 rounded-md hover:bg-purple-500/10 cursor-pointer transition-colors"
                  onClick={() => onNavigate(url)}
                >
                  <Globe className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                  <span className="text-xs text-muted-foreground truncate">
                    {url.replace(/^https?:\/\//, "").replace(/\/$/, "")}
                  </span>
                </div>
              ))}
            </div>
          </>
        )}
      </ScrollArea>
    </div>
  );
}
