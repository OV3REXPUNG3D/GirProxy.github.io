import { useEffect, useRef, useState } from "react";
import {
  Globe,
  ArrowLeft,
  ArrowRight,
  RotateCcw,
  Star,
  Search,
  Shield,
  X,
  Plus,
  Menu,
  Zap,
  Lock,
  Unlock,
  ExternalLink,
  BookOpen,
  Gamepad2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { toast } from "sonner";
import { GAMES, CATEGORIES } from "@/lib/games-data";
import { getProxyUrl, normalizeUrl, getFaviconUrl, buildErrorPage } from "@/lib/proxy";
import { CORS_PROXIES } from "@/lib/games-data";
import GamesView from "@/components/GamesView";
import BookmarkSidebar from "@/components/BookmarkSidebar";

interface Tab {
  id: string;
  url: string;
  title: string;
  loading: boolean;
}

interface Bookmark {
  id: string;
  url: string;
  title: string;
}

export default function Index() {
  const [tabs, setTabs] = useState<Tab[]>([{ id: "tab-1", url: "", title: "New Tab", loading: false }]);
  const [activeTabId, setActiveTabId] = useState("tab-1");
  const [addressInput, setAddressInput] = useState("");
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([
    { id: "b1", url: "https://wikipedia.org", title: "Wikipedia" },
    { id: "b2", url: "https://github.com", title: "GitHub" },
    { id: "b3", url: "https://duckduckgo.com", title: "DuckDuckGo" },
    { id: "b4", url: "https://reddit.com", title: "Reddit" },
    { id: "b5", url: "https://news.ycombinator.com", title: "Hacker News" },
  ]);
  const [history, setHistory] = useState<string[]>([]);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [proxyIndex, setProxyIndex] = useState(0);
  const [view, setView] = useState<"browser" | "games">("browser");
  const [gameCategory, setGameCategory] = useState("All");
  const [gameSearch, setGameSearch] = useState("");
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  const activeTab = tabs.find((t) => t.id === activeTabId) || tabs[0];

  useEffect(() => { setAddressInput(activeTab?.url || ""); }, [activeTabId, activeTab?.url]);

  const addTab = () => {
    const newTab: Tab = { id: `tab-${Date.now()}`, url: "", title: "New Tab", loading: false };
    setTabs((p) => [...p, newTab]);
    setActiveTabId(newTab.id);
    setView("browser");
  };

  const closeTab = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setTabs((prev) => {
      if (prev.length === 1) return [{ id: "tab-1", url: "", title: "New Tab", loading: false }];
      const filtered = prev.filter((t) => t.id !== id);
      if (activeTabId === id) {
        const idx = prev.findIndex((t) => t.id === id);
        const next = prev[idx - 1] || prev[idx + 1];
        if (next) setActiveTabId(next.id);
      }
      return filtered;
    });
  };

  const navigate = async (url: string, isGame = false) => {
    const normalized = normalizeUrl(url);
    if (!normalized) return;

    if (abortRef.current) abortRef.current.abort();
    abortRef.current = new AbortController();

    setTabs((p) => p.map((t) => t.id === activeTabId ? {
      ...t,
      url: normalized,
      title: isGame ? `🎮 ${new URL(normalized).hostname}` : normalized,
      loading: true,
    } : t));
    setAddressInput(normalized);
    setView("browser");
    setHistory((p) => [normalized, ...p.filter((u) => u !== normalized)].slice(0, 50));

    let success = false;
    let lastErr = "";

    for (let attempt = 0; attempt < CORS_PROXIES.length; attempt++) {
      const idx = (proxyIndex + attempt) % CORS_PROXIES.length;
      const proxyUrl = getProxyUrl(normalized, idx);
      try {
        const res = await fetch(proxyUrl, {
          method: "GET",
          signal: abortRef.current.signal,
          headers: { Accept: "text/html,application/xhtml+xml" },
        });
        if (!res.ok) { lastErr = `HTTP ${res.status}`; continue; }

        const ct = res.headers.get("content-type") || "";
        const html = await res.text();
        if (!html || html.length < 50) { lastErr = "Empty response"; continue; }
        if (!ct.includes("text/html") && !ct.includes("application/xhtml") && html.trim().startsWith("{")) {
          lastErr = "Proxy returned JSON error"; continue;
        }

        const baseTag = `<base href="${normalized}" target="_blank">`;
        const charsetMeta = `<meta charset="UTF-8">`;
        let mod = html;
        if (!/<meta[^>]+charset/i.test(html)) mod = html.replace(/<head([^>]*)>/i, `<head$1>${charsetMeta}`);
        mod = mod.replace(/<head([^>]*)>/i, `<head$1>${baseTag}`);
        mod = mod.replace(/<meta[^>]+http-equiv=["']X-Frame-Options["'][^>]*>/gi, "");

        if (iframeRef.current) iframeRef.current.srcdoc = mod;

        const tm = html.match(/<title[^>]*>([^<]*)<\/title>/i);
        const pageTitle = tm?.[1]?.trim() || new URL(normalized).hostname;
        setTabs((p) => p.map((t) => t.id === activeTabId ? { ...t, title: pageTitle, loading: false } : t));
        setProxyIndex(idx);
        success = true;
        break;
      } catch (err: any) {
        if (err.name === "AbortError") return;
        lastErr = err.message || "Network error";
      }
    }

    if (!success) {
      setTabs((p) => p.map((t) => t.id === activeTabId ? { ...t, loading: false } : t));
      toast.error("All proxies failed. Try a different site.");
      if (iframeRef.current) iframeRef.current.srcdoc = buildErrorPage(normalized, lastErr);
    }
  };

  const handleAddressSubmit = (e: React.FormEvent) => { e.preventDefault(); if (addressInput.trim()) navigate(addressInput); };

  const toggleBookmark = () => {
    if (!activeTab?.url) return;
    const exists = bookmarks.find((b) => b.url === activeTab.url);
    if (exists) {
      setBookmarks((p) => p.filter((b) => b.url !== activeTab.url));
      toast.success("Removed bookmark");
    } else {
      setBookmarks((p) => [{ id: `b-${Date.now()}`, url: activeTab.url, title: activeTab.title }, ...p]);
      toast.success("Bookmark added");
    }
  };

  const isBookmarked = !!bookmarks.find((b) => b.url === activeTab?.url);
  const activeProxy = CORS_PROXIES[proxyIndex % CORS_PROXIES.length];

  const filteredGames = GAMES.filter((g) => {
    const mc = gameCategory === "All" || g.category === gameCategory;
    const ms = g.title.toLowerCase().includes(gameSearch.toLowerCase()) || g.description.toLowerCase().includes(gameSearch.toLowerCase());
    return mc && ms;
  });

  return (
    <div className="flex flex-col h-screen bg-background text-foreground overflow-hidden">
      {/* Top Bar */}
      <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-card/60 backdrop-blur-sm">
        <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="lg:hidden shrink-0"><Menu className="h-4 w-4" /></Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[280px] p-0">
            <BookmarkSidebar
              bookmarks={bookmarks}
              history={history}
              onNavigate={(url) => { navigate(url); setSidebarOpen(false); }}
              onDeleteBookmark={(id) => setBookmarks((p) => p.filter((b) => b.id !== id))}
            />
          </SheetContent>
        </Sheet>

        <div className="flex items-center gap-2 shrink-0 mr-1 cursor-pointer"
          onClick={() => {
            setView("browser");
            setTabs((p) => p.map((t) => t.id === activeTabId ? { ...t, url: "", title: "New Tab" } : t));
          }}>
          <div className="h-7 w-7 rounded-lg bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center shadow-sm">
            <Zap className="h-4 w-4 text-white" />
          </div>
          <span className="font-bold text-sm hidden sm:inline bg-gradient-to-r from-purple-400 to-purple-600 bg-clip-text text-transparent">GirProxy</span>
        </div>

        <div className="flex items-center gap-0.5 shrink-0">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toast.info("Back")}><ArrowLeft className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toast.info("Forward")}><ArrowRight className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => activeTab?.url && navigate(activeTab.url)}><RotateCcw className="h-4 w-4" /></Button>
        </div>

        <form onSubmit={handleAddressSubmit} className="flex-1 flex items-center gap-2 min-w-0">
          <div className="flex-1 relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground h-3.5 w-3.5" />
            <Input value={addressInput} onChange={(e) => setAddressInput(e.target.value)} placeholder="Enter URL or search..."
              className="pl-8 pr-10 h-9 text-sm bg-background border-border/80 focus-visible:ring-purple-500/40" />
            <div className="absolute right-2 top-1/2 -translate-y-1/2">
              {activeTab?.url?.startsWith("https") ? <Lock className="h-3.5 w-3.5 text-purple-400" /> : activeTab?.url ? <Unlock className="h-3.5 w-3.5 text-muted-foreground" /> : null}
            </div>
          </div>
        </form>

        <div className="flex items-center gap-0.5 shrink-0">
          <Button variant="ghost" size="icon" className={`h-8 w-8 ${isBookmarked ? "text-purple-400" : ""}`} onClick={toggleBookmark}>
            <Star className="h-4 w-4" fill={isBookmarked ? "currentColor" : "none"} />
          </Button>
          <Button variant={view === "games" ? "secondary" : "ghost"} size="icon" className="h-8 w-8" onClick={() => setView(view === "games" ? "browser" : "games")}>
            <Gamepad2 className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={addTab}><Plus className="h-4 w-4" /></Button>
        </div>
      </div>

      {/* Tabs Bar */}
      <div className="flex items-center gap-1 px-2 py-1.5 border-b border-border bg-card/40 overflow-x-auto scrollbar-hide">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => { setActiveTabId(tab.id); setView("browser"); }}
            className={`group flex items-center gap-2 px-3 py-1.5 rounded-md text-xs min-w-[120px] max-w-[200px] transition-colors ${
              tab.id === activeTabId ? "bg-purple-500/10 text-purple-300 border border-purple-500/20" : "hover:bg-muted text-muted-foreground border border-transparent"
            }`}
          >
            {tab.url ? (
              <img src={getFaviconUrl(tab.url)} alt="" className="h-3.5 w-3.5 shrink-0 rounded-sm" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
            ) : <Globe className="h-3.5 w-3.5 shrink-0" />}
            <span className="truncate flex-1 text-left">{tab.title}</span>
            {tab.loading && <div className="h-3 w-3 rounded-full border-2 border-purple-400 border-t-transparent animate-spin shrink-0" />}
            <span onClick={(e) => closeTab(e, tab.id)} className="opacity-0 group-hover:opacity-100 hover:text-destructive transition-opacity"><X className="h-3 w-3" /></span>
          </button>
        ))}
        <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={addTab}><Plus className="h-3.5 w-3.5" /></Button>
      </div>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        <div className="hidden lg:flex w-[240px] flex-col border-r border-border bg-card/30">
          <BookmarkSidebar bookmarks={bookmarks} history={history} onNavigate={navigate} onDeleteBookmark={(id) => setBookmarks((p) => p.filter((b) => b.id !== id))} />
        </div>

        <div className="flex-1 flex flex-col min-w-0">
          {view === "games" ? (
            <GamesView games={filteredGames} categories={CATEGORIES} activeCategory={gameCategory} search={gameSearch}
              onCategoryChange={setGameCategory} onSearchChange={setGameSearch} onPlay={(url) => navigate(url, true)} />
          ) : !activeTab?.url ? (
            <NewTabView bookmarks={bookmarks} onNavigate={navigate} onOpenGames={() => setView("games")} proxyDomain={activeProxy.replace("https://", "").split("/")[0]} />
          ) : (
            <div className="flex-1 relative bg-white">
              {activeTab.loading && (
                <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-card/90 backdrop-blur-sm gap-3">
                  <div className="h-8 w-8 rounded-full border-[3px] border-purple-400 border-t-transparent animate-spin" />
                  <p className="text-sm text-muted-foreground">Loading via proxy...</p>
                  <p className="text-xs text-muted-foreground/60 max-w-xs text-center">{activeProxy}</p>
                </div>
              )}
              <iframe ref={iframeRef} title={activeTab.title} sandbox="allow-scripts allow-same-origin allow-popups allow-forms" className="w-full h-full border-0" />
            </div>
          )}
        </div>
      </div>

      {/* Status Bar */}
      <div className="flex items-center justify-between px-3 py-1.5 border-t border-border bg-card/40 text-[11px] text-muted-foreground">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1"><Globe className="h-3 w-3" />{activeTab?.url ? new URL(activeTab.url).hostname : "Ready"}</span>
          <span className="hidden sm:inline">Proxy: {activeProxy.replace("https://", "").split("/")[0]}</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1"><BookOpen className="h-3 w-3" />{tabs.length} tab{tabs.length !== 1 ? "s" : ""}</span>
          <span className="flex items-center gap-1"><Star className="h-3 w-3" />{bookmarks.length}</span>
          <span className="flex items-center gap-1"><Gamepad2 className="h-3 w-3" />{GAMES.length} games</span>
        </div>
      </div>
    </div>
  );
}

/* ─── New Tab View ─── */
function NewTabView({ bookmarks, onNavigate, onOpenGames, proxyDomain }: { bookmarks: Bookmark[]; onNavigate: (url: string) => void; onOpenGames: () => void; proxyDomain: string }) {
  const [search, setSearch] = useState("");
  return (
    <div className="flex-1 flex flex-col items-center justify-center gap-6 p-8 overflow-y-auto">
      <div className="text-center space-y-4">
        <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-purple-500 to-purple-700 shadow-lg shadow-purple-500/20 mb-2">
          <Shield className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-300 to-purple-500 bg-clip-text text-transparent">GirProxy</h1>
        <p className="text-muted-foreground max-w-sm">Browse the web anonymously. Your connection is routed through rotating proxy servers for privacy.</p>
      </div>

      <form onSubmit={(e) => { e.preventDefault(); if (search.trim()) onNavigate(search); }} className="w-full max-w-lg relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Enter a URL (e.g. wikipedia.org)" className="pl-10 h-11 text-base bg-card border-border/80 focus-visible:ring-purple-500/40" />
      </form>

      <div className="flex items-center gap-3">
        <Button variant="outline" size="sm" className="gap-2" onClick={onOpenGames}><Gamepad2 className="h-4 w-4 text-purple-400" />Games</Button>
        <Button variant="outline" size="sm" className="gap-2" onClick={() => onNavigate("https://wikipedia.org")}><Globe className="h-4 w-4 text-purple-400" />Wikipedia</Button>
        <Button variant="outline" size="sm" className="gap-2" onClick={() => onNavigate("https://github.com")}><ExternalLink className="h-4 w-4 text-purple-400" />GitHub</Button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 w-full max-w-lg">
        {bookmarks.slice(0, 6).map((bm) => (
          <button key={bm.id} onClick={() => onNavigate(bm.url)} className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-card/60 border border-border/50 hover:border-purple-500/30 hover:bg-purple-500/5 transition-colors text-left">
            <img src={getFaviconUrl(bm.url)} alt="" className="h-5 w-5 rounded-sm shrink-0" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
            <span className="text-sm truncate">{bm.title}</span>
          </button>
        ))}
      </div>

      <div className="flex items-center gap-4 text-xs text-muted-foreground">
        <div className="flex items-center gap-1.5"><div className="h-2 w-2 rounded-full bg-green-400" />Proxy Online</div>
        <div className="flex items-center gap-1.5"><Shield className="h-3 w-3" />{proxyDomain}</div>
        <div className="flex items-center gap-1.5"><Zap className="h-3 w-3" />Fast Routing</div>
      </div>
    </div>
  );
}
