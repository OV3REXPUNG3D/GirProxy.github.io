export interface GameEntry {
  id: string;
  title: string;
  url: string;
  category: string;
  emoji: string;
  description: string;
}

export const GAMES: GameEntry[] = [
  { id: "g1", title: "Slope", url: "https://slopegameio.github.io/", category: "Action", emoji: "🏂", description: "Roll down an endless neon slope" },
  { id: "g2", title: "Tunnel Rush", url: "https://tunnelrush.gitlab.io/", category: "Action", emoji: "🌀", description: "Dodge obstacles in a 3D tunnel" },
  { id: "g3", title: "Rooftop Snipers", url: "https://gamehtml5.github.io/play/rooftop-snipers.html", category: "Action", emoji: "🎯", description: "Snipe your friend off the roof" },
  { id: "g4", title: "Flappy Bird", url: "https://nebezb.com/floppybird/", category: "Arcade", emoji: "🐦", description: "Tap to flap through pipes" },
  { id: "g5", title: "Chrome Dino", url: "https://wayou.github.io/t-rex-runner/", category: "Arcade", emoji: "🦖", description: "Jump cacti in the desert" },
  { id: "g6", title: "Doodle Jump", url: "https://gamehtml5.github.io/play/doodle-jump.html", category: "Arcade", emoji: "🐛", description: "Bounce your way to space" },
  { id: "g7", title: "Snake", url: "https://playsnake.org/", category: "Arcade", emoji: "🐍", description: "Classic snake eats and grows" },
  { id: "g8", title: "2048", url: "https://gabrielecirulli.github.io/2048/", category: "Puzzle", emoji: "🔢", description: "Slide tiles to reach 2048" },
  { id: "g9", title: "Tetris", url: "https://tetris.com/play-tetris", category: "Puzzle", emoji: "🧱", description: "Stack blocks, clear lines" },
  { id: "g10", title: "HexGL", url: "https://hexgl.bkcore.com/play/", category: "Puzzle", emoji: "🔷", description: "Futuristic hovercraft racing" },
  { id: "g11", title: "Minecraft Classic", url: "https://classic.minecraft.net/", category: "Puzzle", emoji: "⛏️", description: "Place blocks in creative mode" },
  { id: "g12", title: "Moto X3M", url: "https://gamehtml5.github.io/play/moto-x3m.html", category: "Racing", emoji: "🏍️", description: "Stunt bike racing" },
  { id: "g13", title: "Moto X3M Pool", url: "https://gamehtml5.github.io/play/moto-x3m-pool-party.html", category: "Racing", emoji: "🏊", description: "Summer pool bike stunts" },
  { id: "g14", title: "Madalin Stunt Cars 2", url: "https://gamehtml5.github.io/play/madalin-stunt-cars-2.html", category: "Racing", emoji: "🚗", description: "Open world car stunts" },
  { id: "g15", title: "Bullet Force", url: "https://gamehtml5.github.io/play/bullet-force.html", category: "Shooter", emoji: "🔫", description: "Multiplayer FPS action" },
  { id: "g16", title: "Smash Karts", url: "https://smashkarts.io/", category: "Shooter", emoji: "🛒", description: "Kart battle royale" },
  { id: "g17", title: "Getaway Shootout", url: "https://gamehtml5.github.io/play/getaway-shootout.html", category: "Shooter", emoji: "🏃", description: "Race to the exit" },
];

export const CATEGORIES = ["All", "Action", "Arcade", "Puzzle", "Racing", "Shooter"];

export const CORS_PROXIES = [
  "https://api.allorigins.win/raw?url=",
  "https://api.codetabs.com/v1/proxy?quest=",
  "https://corsproxy.io/?",
  "https://cors.lol/?url=",
];
