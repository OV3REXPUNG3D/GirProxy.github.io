import { CORS_PROXIES } from "./games-data";

export function getProxyUrl(url: string, index: number) {
  const encoded = encodeURIComponent(url);
  return CORS_PROXIES[index % CORS_PROXIES.length] + encoded;
}

export function normalizeUrl(input: string): string {
  let url = input.trim();
  if (!url) return "";
  if (!/^https?:\/\//i.test(url)) url = "https://" + url;
  return url;
}

export function getFaviconUrl(url: string): string {
  try {
    const u = new URL(url);
    return `https://www.google.com/s2/favicons?domain=${u.hostname}&sz=32`;
  } catch {
    return "";
  }
}

export function buildErrorPage(url: string, error: string) {
  return `
    <html>
      <head>
        <meta charset="UTF-8">
        <style>
          body{font-family:system-ui,-apple-system,sans-serif;background:#0a0a0f;color:#e2e8f0;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;}
          .box{max-width:480px;padding:2rem;}
          h1{color:#a855f7;font-size:1.5rem;margin-bottom:0.5rem;}
          p{color:#94a3b8;line-height:1.6;margin:0.5rem 0;}
          code{background:rgba(168,85,247,0.15);padding:2px 6px;border-radius:4px;color:#c084fc;font-size:0.85em;}
          .tip{margin-top:1rem;font-size:0.85rem;color:#64748b;padding:1rem;background:rgba(255,255,255,0.03);border-radius:8px;}
        </style>
      </head>
      <body>
        <div class="box">
          <h1>⚠ Proxy Error</h1>
          <p>Could not load <code>${url}</code></p>
          <p>Error: <code>${error}</code></p>
          <div class="tip">
            Tips:<br>
            • Try a different website (Wikipedia, GitHub work well)<br>
            • Some sites actively block proxy access<br>
            • Try again in a few seconds — proxies rotate automatically
          </div>
        </div>
      </body>
    </html>
  `;
}
